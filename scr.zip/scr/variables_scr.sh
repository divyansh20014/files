#!/usr/bin/env bash

# namespace where scr should live
export scr_ns=viya

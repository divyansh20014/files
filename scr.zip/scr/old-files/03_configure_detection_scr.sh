#!/usr/bin/env bash
source ../variables.sh
source ./variables_scr.sh

export PATH=$(realpath ../tools):$PATH
export iac_base=/home/sas/deployments/viya4-iac-azure/workspace
export iac_deploy=fsi-presales-dev-01
export KUBECONFIG=$iac_base/$iac_deploy/fsi-presales-dev-01-aks-kubeconfig.conf


#execution mode of goODE
#kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_MODE=SCR
#kubectl -n ${NS} set env deployment/sas-detection -c sas-detection SAS_DETECTION_SERVICE_URL="http://localhost:8080"

#SCR properties
#kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_URL=http://sas-sda-scr-viyar11.${scr_ns}.svc.cluster.local:8080

#execution mode of goODE
#kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_MODE=SCR
#kubectl -n ${NS} set env deployment/sas-detection -c sas-detection SAS_DETECTION_SERVICE_URL="http://localhost:8080"

#SCR properties
#kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_URL=http://sas-sda-scr-viyar11.${scr_ns}.svc.cluster.local:8080

# PS Added based on the sas-detection example in sas-bases
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_SERVICE_URL="http://localhost:8080" #was 8777
kubectl -n ${NS} set env deployment/sas-detection PORT="8080"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_MODE="SCR"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_EXECUTION_URL="http://localhost:8080"
kubectl -n ${NS} set env deployment/sas-detection SAS_LOG_LEVEL="DEBUG"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_SERVER="fsi-dev-01.fsipresalesazure.unx.sas.com:9092"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_CONSUMER_ENABLED="true"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_TDR_TOPIC="transaction-detection-repository"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_DRULESTOPIC="disabled-rules"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_REJECTTOPIC="transaction-reject"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_KAFKA_TOPIC="input-transactions"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_REDIS_STANDALONE_REDISSERVICEADDRESS="fsi-dev-01.fsipresalesazure.unx.sas.com:6379"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_REDIS_KEY_PREFIX="SAS|0"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_DISABLEMETRICS="false"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_SLA="85"
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_SETVERBOSE=""
kubectl -n ${NS} set env deployment/sas-detection SAS_DETECTION_PROCESSING_OUTPUTSEGMENTS=""


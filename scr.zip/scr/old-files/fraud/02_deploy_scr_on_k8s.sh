#!/usr/bin/env bash

source ../../variables.sh
source ../variables_scr.sh

export PATH=$(realpath ../tools):$PATH
export iac_base=/home/sas/deployments/viya4-iac-azure/workspace
export iac_deploy=fsi-presales-dev-03
export KUBECONFIG=$iac_base/$iac_deploy/fsi-presales-dev-03-aks-kubeconfig.conf

###############################################
#Create service, deployment and ingress for scr
###############################################
kubectl create ns ${scr_ns}
#export some variables for substitution in manifest
export myACRendpoint=$(cat /home/sas/deployments/viya4-iac-azure/workspace/fsi-presales-dev-03/fsi-presales-dev-03.tfstate | jq -r .outputs.cr_endpoint.value) 
export INGRESS_HOST=$(kubectl -n ${NS} get cm $(kubectl -n ${NS} get cm -o custom-columns=:metadata.name | grep ingress-input) -o=jsonpath='{.data.INGRESS_HOST}')

#envsubst < sas-sda-scr-template.yaml > /home/sas/deployments/viya4-deployment/fsi-presales-dev-03/fd-azure-deployment/scr/sas-sda-scr.yaml

kubectl -n ${scr_ns} apply -f /home/sas/deployments/viya4-deployment/fsi-presales-dev-03/fd-azure-deployment/scr/fraud/sas-sda-scr.yaml
#kubectl -n ${scr_ns} apply -f /home/sas/deployments/viya4-deployment/fsi-presales-dev-03/fd-azure-deployment/scr/fraud/sas-sda-scr-v2.yaml


#!/usr/bin/env bash
export KAFKA_CLUSTER_NS=kafka
export OLD_ORG_NAME=fraud
export NEW_ORG_NAME=aplct

sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/input-transactions-topic.yaml
sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/transaction-detection-repository-topic.yaml
sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/transaction-reject-topic.yaml
sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/ruletest-transaction-topic.yaml
sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/estimate-transaction-topic.yaml
sed -i -e "s/$OLD_ORG_NAME/$NEW_ORG_NAME/g" deployments/disabled-rules-topic.yaml

#Create topics required for fraud detection
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/input-transactions-topic.yaml
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/transaction-detection-repository-topic.yaml
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/transaction-reject-topic.yaml
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/ruletest-transaction-topic.yaml
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/estimate-transaction-topic.yaml
kubectl -n ${KAFKA_CLUSTER_NS} apply -f deployments/disabled-rules-topic.yaml


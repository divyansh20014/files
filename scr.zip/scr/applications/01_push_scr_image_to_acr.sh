#!/usr/bin/env bash

export PATH=$(realpath ../tools):$PATH

export myACRendpoint=$(cat /home/sas/deployments/viya4-iac-azure/workspace/fsi-presales-dev-01/fsi-presales-dev-01.tfstate | jq -r .outputs.cr_endpoint.value) 

#Fetch latest scr container from R&D container registry and push to azure container registry
#docker pull registry.unx.sas.com/fraudmgmt/viya_r11:latest
#docker tag registry.unx.sas.com/fraudmgmt/viya_r11:latest ${myACRendpoint}/fraudmgmt/viya_r11:latest
#az acr login -n ${myACRendpoint}
#docker push ${myACRendpoint}/fraudmgmt/viya_r11:latest

# Fetch latest sas-detection container
#docker pull crcache-az-us-east.unx.sas.com/viya-4-x64_oci_linux_2-docker/sas-detection:latest
#docker tag crcache-az-us-east.unx.sas.com/viya-4-x64_oci_linux_2-docker/sas-detection:latest ${myACRendpoint}/viya-4-x64_oci_linux_2-docker/sas-detection:latest
#az acr login -n ${myACRendpoint}
#docker push ${myACRendpoint}/viya-4-x64_oci_linux_2-docker/sas-detection:latest

# Latest Release
docker pull repulpmaster.unx.sas.com/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest
docker tag repulpmaster.unx.sas.com/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest ${myACRendpoint}/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest
az acr login -n ${myACRendpoint}
docker push ${myACRendpoint}/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest

# Prod Release
docker pull repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest
docker tag repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest
az acr login -n ${myACRendpoint}
docker push ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest

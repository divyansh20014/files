#!/usr/bin/env bash

source ../variables_scr.sh

export PATH=$(realpath ../tools):$PATH

###############################################
#Create service, deployment and ingress for scr
###############################################
kubectl create ns ${scr_ns}

kubectl -n ${scr_ns} apply -f /opt/sas/deploy/viya/sda/scr/applications/sas-sda-scr.yaml

# Generate certs for SDA
#kubectl -n ${scr_ns} apply -f sas-sda-certificate_generator.yaml


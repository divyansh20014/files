#!/bin/sh
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.6.3/cert-manager.crds.yaml
kubectl apply -f sas-sda-certificate_generator.yaml

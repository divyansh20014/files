#!/usr/bin/env bash

export PATH=$(realpath ../tools):$PATH
export NS=viya
export SCR_NS=viya
export myACRendpoint=docker-registry:5000
export INGRESS_HOST=$(kubectl -n ${NS} get cm $(kubectl -n ${NS} get cm -o custom-columns=:metadata.name | grep ingress-input) -o=jsonpath='{.data.INGRESS_HOST}')

###############################################
#Create service, deployment and ingress for scr
###############################################
kubectl create ns ${SCR_NS}
kubectl -n ${SCR_NS} apply -f sas-sda-scr.yaml

# Generate certs for SDA
#kubectl -n ${scr_ns} apply -f sas-sda-certificate_generator.yaml


#!/usr/bin/env bash

export PATH=$(realpath ../tools):$PATH

export myACRendpoint=docker-registry:5000 

# Latest Release
#docker pull repulpmaster.unx.sas.com/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest
#docker tag repulpmaster.unx.sas.com/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest ${myACRendpoint}/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest
#docker login ${myACRendpoint} -u sas -p Orion123
#docker push ${myACRendpoint}/cdp-release-x64_oci_linux_2-docker-latest/sas-detection:latest

# Prod Release
#docker pull repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest
#docker tag repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest
#docker login -n ${myACRendpoint}
#docker push ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest

# Specific Release (so you can align to stable release version) - 2023.08!
docker pull repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:1.21.0-20230807.1691440929692
docker tag repulpmaster.unx.sas.com/viya-4-x64_oci_linux_2-docker-prod/sas-detection:1.21.0-20230807.1691440929692 ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest
docker login ${myACRendpoint} -u sas -p Orion123
docker push ${myACRendpoint}/viya-4-x64_oci_linux_2-docker-prod/sas-detection:latest


#!/bin/sh

kubectl create secret generic database-secrets --from-literal=db.secrets=connectionstring=DRIVER=SQL";"CONOPTS="("DRIVER=POSTGRES";"CATALOG=public";"UID=dbmsowner";"PWD=Orion123";"SERVER=sas-crunchy-platform-postgres-primary";"PORT=5432";"DB=postgres";"SCHEMA=extdata")" --namespace=viya

kubectl create configmap database-config --from-literal=db.config=maxRetries=10 --from-literal=retryIntervalSeconds=10 --from-literal=autoCommit=false --from-literal=connectionCheckStatement="select * from network_view" -n viya
